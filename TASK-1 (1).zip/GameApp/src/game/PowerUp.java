package game;

//Abstract class for PowerUp
public abstract class PowerUp {
 public abstract void activate();
}

