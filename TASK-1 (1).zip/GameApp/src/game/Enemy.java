package game;

public abstract class Enemy {
    public abstract void attack();
}







