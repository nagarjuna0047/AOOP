package game;

public class HardPowerUp extends PowerUp {
    @Override
    public void activate() {
        System.out.println("Hard PowerUp activated: Shields!");
    }
}