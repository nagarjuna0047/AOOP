package game;

//Abstract class for Weapon
public abstract class Weapon {
 public abstract void use();
}
