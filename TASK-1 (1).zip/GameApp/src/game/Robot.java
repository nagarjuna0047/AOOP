package game;

public class Robot extends Enemy {
    @Override
    public void attack() {
        System.out.println("Robot attacks with laser beams!");
    }
}
