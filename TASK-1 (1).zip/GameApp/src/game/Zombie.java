package game;

public class Zombie extends Enemy {
    @Override
    public void attack() {
        System.out.println("Zombie attacks with a bite!");
    }
}
