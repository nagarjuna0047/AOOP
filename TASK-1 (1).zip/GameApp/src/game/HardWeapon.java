package game;

public class HardWeapon extends Weapon {
    @Override
    public void use() {
        System.out.println("Hard Weapon used: High damage");
    }
}
