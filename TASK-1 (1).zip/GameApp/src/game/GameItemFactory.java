package game;

//Abstract Factory
public interface GameItemFactory {
 Weapon createWeapon();
 PowerUp createPowerUp();
}




